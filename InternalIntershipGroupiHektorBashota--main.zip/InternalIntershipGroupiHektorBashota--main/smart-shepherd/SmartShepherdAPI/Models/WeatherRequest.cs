namespace SmartShepherdAPI.Models
{
    public class WeatherRequest
    {
        public required string Location { get; set; }
    }
}